namespace Domain.Entities
{
    public class Produto
    {
        public string CodProduto { get; set; }
        public string DesProduto { get; set; }
        public string StaStatus { get; set; }
    }
}
