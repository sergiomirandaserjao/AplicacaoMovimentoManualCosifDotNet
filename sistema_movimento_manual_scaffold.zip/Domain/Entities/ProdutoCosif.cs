namespace Domain.Entities
{
    public class ProdutoCosif
    {
        public string CodProduto { get; set; }
        public string CodCosif { get; set; }
        public string CodClassificacao { get; set; }
        public string StaStatus { get; set; }
    }
}
